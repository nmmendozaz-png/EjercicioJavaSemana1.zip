public class Main {
    public static void main(String[] args) {
        System.out.println("¡Hola, este es mi primer proyecto en Java publicado en GitHub!");
    }
}
