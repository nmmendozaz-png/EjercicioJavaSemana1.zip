# EjercicioJavaSemana1

Proyecto sencillo en Java con un `main`.